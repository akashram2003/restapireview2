package com.example.demo.modelO;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Omodel {
	@Id
	private int id;
	private String Playername;
	private String Playercategory;
	private int fees;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlayername() {
		return Playername;
	}
	public void setPlayername(String playername) {
		Playername = playername;
	}
	public String getPlayercategory() {
		return Playercategory;
	}
	public void setPlayercategory(String playercategory) {
		Playercategory = playercategory;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	
	
	

}